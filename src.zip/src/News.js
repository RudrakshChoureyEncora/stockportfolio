export default function News() {
  return <h1>this is news page</h1>;
}
